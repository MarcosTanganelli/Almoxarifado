-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           8.0.33 - MySQL Community Server - GPL
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.4.0.6659
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para almoxarifado
CREATE DATABASE IF NOT EXISTS `almoxarifado` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `almoxarifado`;

-- Copiando estrutura para tabela almoxarifado.estoque
CREATE TABLE IF NOT EXISTS `estoque` (
  `cod_mat` int DEFAULT NULL,
  `material` varchar(150) DEFAULT NULL,
  `local` varchar(150) DEFAULT NULL,
  `unidade` varchar(150) DEFAULT NULL,
  `saldo` int NOT NULL DEFAULT '0',
  CONSTRAINT `estoque_chk_1` CHECK ((`saldo` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Copiando dados para a tabela almoxarifado.estoque: ~10 rows (aproximadamente)
INSERT IGNORE INTO `estoque` (`cod_mat`, `material`, `local`, `unidade`, `saldo`) VALUES
	(2, '3', '5', '6', 7),
	(4, '7', '8', '9', 2),
	(44, '5', '6', '7', 6),
	(1111, '1111', '1111', '1111', 0),
	(714, 'Bóia P/ Caixa D\'Água, Metal, De 1\n', '', 'PÇ\n', 17),
	(9093, 'Bucha De Redução, 32 X 25mm\n', '', 'PÇ\n', 36),
	(763, 'Caixa Sifonada Quadrada C/ 3 Entradas, 100 X 125 X 50mm\n', '', 'PÇ\n', 7),
	(200001, 'Válvula 2 1/4" Corpo Inox Multiuso: Tanques - Pias - Lavatório\n', '', 'PÇ\n', 1),
	(18978, 'Válvula P/ Lavatório, Em Metal\n', '', 'PÇ\n', 51),
	(43423, 'Torneira Em Metal P/Jardim,3/4 Acion. Alavanca\n', '', 'PÇ\n', 17);

-- Copiando estrutura para tabela almoxarifado.saida
CREATE TABLE IF NOT EXISTS `saida` (
  `chamado_id` int DEFAULT NULL,
  `tecnico` varchar(50) DEFAULT NULL,
  `material` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Copiando dados para a tabela almoxarifado.saida: ~0 rows (aproximadamente)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
